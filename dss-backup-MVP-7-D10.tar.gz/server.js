/*
VERSION: MVP-7-D10 (STRATEGY ENGINE)
*/

const express = require("express");
const app = express();
app.use(express.json());

const VERSION = "MVP-7-D10";

/* =========================
   WEIGHTS
========================= */
const WEIGHTS = {
  rates: 0.2,
  liquidity: 0.2,
  crude: 0.15,
  fii: 0.2,
  vix: 0.15,
  trend: 0.1,
};

/* =========================
   MEMORY
========================= */
let lastCrudeSignal = "falling";
let lastVixSignal = "low";
let lastRegime = null;
let lastStableRegime = null;

/* =========================
   SCORING
========================= */
function scoreSignal(type, value) {
  const map = {
    rates: { rising: -1, falling: 1 },
    liquidity: { supportive: 1, tight: -1 },
    crude: { rising: -1, falling: 1 },
    fii: { buying: 1, selling: -1 },
    vix: { low: 1, high: -1 },
    trend: { bullish: 1, bearish: -1 },
  };
  return map[type]?.[value] ?? 0;
}

/* =========================
   AUTO FILL
========================= */
function autoFillInputs(body) {
  return {
    rates: body.rates || "rising",
    crude: body.crude || lastCrudeSignal,
    fii: "buying",
    liquidity: "supportive",
    vix: lastVixSignal,
    trend: body.autoTrend ? "bullish" : "bearish",
  };
}

/* =========================
   REGIME ENGINE
========================= */
function getRegime(score) {
  if (score >= 70) return "STRONG RISK ON";
  if (score >= 55) return "RISK ON";
  if (score >= 45) return "NEUTRAL";
  if (score >= 30) return "RISK OFF";
  return "STRONG RISK OFF";
}

/* =========================
   CONFIDENCE ENGINE
========================= */
function getConfidence(signals) {
  const positives = Object.values(signals).filter(s => s.score === 1).length;
  return Math.round((positives / 6) * 100);
}

/* =========================
   MARKET QUALITY
========================= */
function getMarketQuality(confidence) {
  if (confidence >= 70) return "STRONG";
  if (confidence >= 50) return "MODERATE";
  return "WEAK";
}

/* =========================
   SECTOR ALLOCATION
========================= */
function getSectorAllocation(regime) {
  if (regime === "STRONG RISK ON") {
    return { NBFC: 35, PSU_BANK: 35, IT: 20, FMCG: 10 };
  }
  if (regime === "RISK ON") {
    return { NBFC: 30, PSU_BANK: 30, IT: 25, FMCG: 15 };
  }
  if (regime === "RISK OFF") {
    return { NBFC: 15, PSU_BANK: 15, IT: 30, FMCG: 40 };
  }
  return { NBFC: 20, PSU_BANK: 20, IT: 30, FMCG: 30 };
}

/* =========================
   STRATEGY ENGINE (NEW)
========================= */
function buildStrategy(regime, confidence, marketQuality, sectorAllocation) {
  let stance = "NEUTRAL";
  let positionSizing = "MEDIUM";
  let riskManagement = [];
  let preferredSectors = Object.keys(sectorAllocation);
  let avoid = [];

  if (regime === "STRONG RISK ON") {
    stance = "AGGRESSIVE LONG";
    positionSizing = confidence > 75 ? "HIGH" : "MEDIUM";
    avoid = ["FMCG"];
  }

  if (regime === "RISK ON") {
    stance = "LONG BIAS";
    positionSizing = "MEDIUM";
  }

  if (regime === "RISK OFF") {
    stance = "DEFENSIVE";
    positionSizing = "LOW";
    avoid = ["NBFC", "PSU_BANK"];
  }

  if (regime === "STRONG RISK OFF") {
    stance = "RISK OFF / CAPITAL PROTECTION";
    positionSizing = "VERY LOW";
    avoid = ["NBFC", "PSU_BANK"];
  }

  // Risk overlays
  if (marketQuality === "WEAK") {
    positionSizing = "LOW";
    riskManagement.push("Reduce exposure due to weak alignment");
  }

  if (confidence < 50) {
    riskManagement.push("Avoid aggressive trades");
  }

  return {
    stance,
    positionSizing,
    preferredSectors,
    avoid,
    riskManagement,
  };
}

/* =========================
   EXPLANATION ENGINE
========================= */
function buildExplanation(signals) {
  const positive = [];
  const negative = [];

  for (const key in signals) {
    if (signals[key].score === 1) positive.push(key);
    else negative.push(key);
  }

  return {
    summary: "Market driven by macro signals",
    keyDrivers: positive,
    riskFlags: negative,
    reasoning:
      "Positive: " + positive.join(", ") +
      " | Negative: " + negative.join(", "),
  };
}

/* =========================
   ROUTES
========================= */
app.get("/health", (req, res) => {
  res.json({ status: "OK", version: VERSION });
});

app.post("/brain-auto", (req, res) => {
  const inputs = autoFillInputs(req.body);

  const signals = {};
  let composite = 0;

  for (const key in WEIGHTS) {
    const score = scoreSignal(key, inputs[key]);
    signals[key] = {
      value: inputs[key],
      score,
      weight: WEIGHTS[key],
      strength: Math.abs(score) === 1 ? "strong" : "neutral",
    };
    composite += score * WEIGHTS[key] * 100;
  }

  const compositeScore = Math.round(composite);
  const regime = getRegime(compositeScore);
  const confidence = getConfidence(signals);
  const marketQuality = getMarketQuality(confidence);
  const sectorAllocation = getSectorAllocation(regime);
  const strategy = buildStrategy(regime, confidence, marketQuality, sectorAllocation);
  const explanation = buildExplanation(signals);

  res.json({
    version: VERSION,
    inputsUsed: inputs,
    signals,
    regime,
    compositeScore,
    confidence,
    marketQuality,
    sectorAllocation,
    strategy,
    explanation,
  });
});

/* =========================
   SERVER
========================= */
app.listen(3000, () => {
  console.log("DSS running on port 3000 (" + VERSION + ")");
});
